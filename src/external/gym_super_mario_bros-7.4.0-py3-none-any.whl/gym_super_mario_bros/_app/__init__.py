"""The application code for running this package from the command line."""
